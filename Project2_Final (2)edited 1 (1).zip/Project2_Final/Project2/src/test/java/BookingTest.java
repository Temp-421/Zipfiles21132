
import AttractionPage.AttractionsPage;
import HomePage.HomePage;
import HotelResultPage.HotelResultsPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class BookingTest {
    WebDriver driver;
    HomePage home;
    HotelResultsPage results;
    AttractionsPage attractions;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.booking.com/index.en-gb.html");

        home = new HomePage(driver);
        results = new HotelResultsPage(driver);
        attractions = new AttractionsPage(driver);
    }

    @Test(priority = 1)
    public void testHotelSearchAndSort() {
        home.dismissPopup();
        home.searchForHotels("Nairobi", "14 May 2026", "18 May 2026");
        results.sortByRating();
        results.getTopHotels(3);
    }

    @Test(priority = 2, dependsOnMethods = "testHotelSearchAndSort")
    public void testAttractionSearch() throws InterruptedException {
        attractions.openAttractionsTab();
        attractions.findAttractions("Nairobi");
    }
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}